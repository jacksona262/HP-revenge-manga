# Chapter 1 page reviews

Reviews distinguish finished pages from drafts that need correction.

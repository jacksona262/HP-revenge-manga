# Chapter-specific continuity guides

These guides preserve childhood appearances, supporting cast and unnamed extras. The requested script controls Jason as an eighth grader at 5ft2 and names Chris Harding for this chapter. They do not silently resolve unrelated global roster conflicts.

# Chapter 1 artwork prompts

Exact page scripts and image reference inputs are retained here.

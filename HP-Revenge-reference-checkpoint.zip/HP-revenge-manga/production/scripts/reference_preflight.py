"""Read every existing sheet for an identity before a generation request."""
import argparse
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('sheet_id')
args = parser.parse_args()
manifest = json.loads((root / 'canon/reference-manifest.json').read_text())
all_slots = [s for section in ['characters','locations','backgrounds','gangs'] for s in manifest[section]]
slot = next((s for s in all_slots if s['id'] == args.sheet_id), None)
if slot is None:
    raise SystemExit('Unknown sheet ID')
print(json.dumps(slot, indent=2))
if 'identity' in slot:
    siblings = [s for s in manifest['characters'] if s['identity'] == slot['identity']]
    print('\nSame identity in other sheet slots:')
    for sibling in siblings:
        image = root / sibling['output']
        print(sibling['id'], sibling['gang_outfit'], 'EXISTS' if image.exists() else 'not generated', image)
    for image in sorted((root / 'characters/sheets').glob(f'*{slot["identity"]}*')):
        print('Existing version to inspect:', image)
print('\nRead canon/conflicts.md and inspect the listed source images with view_image before calling image generation.')
print('This command inventories references; it does not claim that visual review was performed.')
